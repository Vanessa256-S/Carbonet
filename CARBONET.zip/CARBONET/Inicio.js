
function validate(){
    var logemail=document.getElementById("logemail").value;
    var password=document.getElementById("password").value;
    if(logemail=="Admin"&& password=="1234@"){
        alert("Ingreso exitosamente");
        window.location="index.html";
        return false;
    } if(logemail=="Cliente"&& password=="123acceso"){
        alert("Ingreso exitosamente");
        window.location-"index.html";
        return false;
    }
    else{
    }
    alert("USUARIO O CONTRASEÑA INCORRECTA")

}